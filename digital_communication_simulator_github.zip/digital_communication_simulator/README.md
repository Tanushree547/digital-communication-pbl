# Digital Communication Simulator Pro

A Streamlit application demonstrating:
- LFSR-based scrambling using XOR
- NRZ-L, NRZ-I, and Manchester line coding
- Gaussian, impulse, and no-noise channel options
- Received waveforms, recovered bits, accuracy, and bit error rate

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy from GitHub using Streamlit Community Cloud

1. Upload `app.py` and `requirements.txt` to the root of a GitHub repository.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Select **Create app**, choose the repository and branch, and set the main file path to `app.py`.
4. Click **Deploy**.

## Run or prepare files in Google Colab

Upload this project folder's `app.py` and `requirements.txt` to your GitHub repository. Do not put `%%writefile` at the top of the GitHub `app.py`; that command is only for a Colab notebook cell.
